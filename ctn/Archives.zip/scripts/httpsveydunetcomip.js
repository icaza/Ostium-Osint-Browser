document.body.style.backgroundImage    = "url('https://veydunet.com/2x24/ost/nh3_1.jpg')"; 
document.body.style.backgroundRepeat   = "no-repeat"; 
document.body.style.backgroundPosition = "center"; 
document.body.style.backgroundSize     = "cover";