document.body.style.backgroundImage    = "url('https://www.onespan.com/sites/default/files/2019-03/hacking.jpg')"; 
document.body.style.backgroundRepeat   = "no-repeat"; 
document.body.style.backgroundPosition = "center"; 
document.body.style.backgroundSize     = "cover";
/* https://veydunet.com/2x24/ost/nh3_1.jpg */